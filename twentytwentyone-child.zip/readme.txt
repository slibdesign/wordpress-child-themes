=== twentytwentyone ===
Contributors: wpchildtheme
Tags: wpchildtheme, [twentytwentyone], [twentytwentyone-child.zip], theme-zip, wordpress, child theme, child-theme, admin, dashboard, code, development
Requires at least: 2.7
Tested up to: 6.7
Stable tag: 1.0.1
License: GPLv3

Twenty Twenty-One Child Theme
[Twenty Twenty-One WordPress child theme](https://wpchildtheme.co.uk/twenty-twenty-one/) is built for the Twenty Twenty-One parent WordPress theme by wordpressdotorg

== Description ==
wpchildtheme [a framework for WP theme modification](https://wpchildtheme.co.uk)
Download a WordPress child theme to get started.
Search on wpchildtheme.co.uk
(Browse 14,075 WP child themes)[https://wpchildtheme.co.uk/category/wordpress-org/]
wpchildtheme makes it easier for web developers and entrepreneurs to source and use a WordPress child theme 
Update your parent theme without losing customisations
Speed up development using a readymade parent WordPress theme and adding only customisations to a child theme
Maintain build integrity with layered .js, .css, .php and other asset files
Push updates from development server to production server easily with the -child portable theme extension
Test your code on more than one WordPress website

== Latest Support ==
(Theme Download Information)[https://wpchildtheme.co.uk/child-theme-download-information/]

== -child Theme Features ==
twentytwentyone-child/style.css Enqueued stylesheet file
twentytwentyone-child/js/scripts.js Enqueued JavaScript file
twentytwentyone-child/functions.php PHP hooks and filters file
twentytwentyone-child/screenshot.png (1200px x 900px) Screenshot
twentytwentyone-child/readme.txt Project information
WordPress Dashboard settings page

== Theme Link ==
[https://wpchildtheme.co.uk/twenty-twenty-one/](https://wpchildtheme.co.uk/twenty-twenty-one/)

== Installation ==
Method 1. Activate the plugin through the 'Plugins' menu in WordPress.
Method 2. Extract the zipped file and upload the folder `twentytwentyone` to `/wp-content/themes/` directory.

== Changelog ==
= 1.0.1 - 25 January 2025 =
* UI Changes

= 1.0.0 - 21 December 2024 =
* Initial Release
