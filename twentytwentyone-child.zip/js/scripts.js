jQuery(document).ready(function($) 
{

    
});